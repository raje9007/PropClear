import { Link } from "wouter";

const servicesList = [
  {
    icon: "🏠",
    name: "Property Purchase Verification",
    desc: "Complete verification before buying any property.",
  },
  {
    icon: "🤝",
    name: "Property Sale Readiness Check",
    desc: "Ensure your property is 100% sale-ready.",
  },
  {
    icon: "📋",
    name: "Mutation Verification",
    desc: "Verify mutation status & get guidance.",
  },
  {
    icon: "📄",
    name: "Freehold Conversion Check",
    desc: "Check freehold eligibility & conversion documents.",
  },
  {
    icon: "🏦",
    name: "Loan Eligibility Document Review",
    desc: "Verify documents for home loan approval.",
  },
  {
    icon: "🔍",
    name: "Legal Document Audit",
    desc: "In-depth audit of property documents.",
  },
];

const howItWorks = [
  { icon: "☁️", title: "Upload Documents", desc: "Submit soft copies of your property documents securely." },
  { icon: "👤", title: "Expert Verification", desc: "Our specialists verify across 11+ checkpoints." },
  { icon: "📋", title: "Detailed Report", desc: "Get a 48-hour detailed verification report." },
  { icon: "🛡️", title: "Take Action", desc: "Make informed decisions with complete confidence." },
];

const docCards = [
  { title: "Sale Deed", offsetX: 30, rotate: "-4deg" },
  { title: "Mutation Letter", offsetX: -12, rotate: "-1deg" },
  { title: "Registry Copy", offsetX: 20, rotate: "3deg" },
  { title: "CERSAI Report", offsetX: -16, rotate: "-2deg" },
];

export default function Home() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#1A1A2E" }}>

      {/* HERO */}
      <section style={{
        background: "linear-gradient(135deg, #EEF4FB 0%, #F0F6FF 60%, #EAF2FF 100%)",
        padding: "60px 32px 56px",
        overflow: "hidden",
      }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48, alignItems: "center" }}>

          {/* Left */}
          <div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#FDF6E3", border: "1px solid #C9A84C", borderRadius: 20, padding: "6px 16px", fontSize: 12, fontWeight: 700, color: "#8B6914", letterSpacing: 0.5, marginBottom: 26 }}>
              ⭐ 9+ YEARS OF DELHI PROPERTY EXPERIENCE
            </div>

            <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(30px, 4vw, 48px)", lineHeight: 1.2, marginBottom: 20, color: "#0D1B2A" }}>
              Avoid Costly<br />
              Property Mistakes<br />
              <span style={{ color: "#C9A84C" }}>Before It's Too Late</span>
            </h1>

            <p style={{ fontSize: 15, fontWeight: 700, color: "#1B3A6B", marginBottom: 12 }}>Delhi NCR Property Verification Experts</p>

            <p style={{ fontSize: 14, color: "#4A5568", lineHeight: 1.8, marginBottom: 32, maxWidth: 420 }}>
              We verify property documents, ownership, mutation, freehold status, liens & more — so you buy, sell or transfer with <strong>100% confidence.</strong>
            </p>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <Link href="/submit" style={{ background: "#C9A84C", color: "#0D1B2A", padding: "13px 28px", borderRadius: 8, fontWeight: 700, fontSize: 15, textDecoration: "none", display: "inline-block" }}>
                Submit Documents
              </Link>
              <Link href="/services" style={{ background: "#fff", color: "#1B3A6B", border: "2px solid #1B3A6B", padding: "13px 28px", borderRadius: 8, fontWeight: 700, fontSize: 15, textDecoration: "none", display: "inline-block" }}>
                View Plans & Pricing
              </Link>
            </div>
          </div>

          {/* Right — Document stack */}
          <div style={{ position: "relative", height: 460, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>

            {/* Background soft circle */}
            <div style={{
              position: "absolute", top: "50%", left: "50%",
              transform: "translate(-50%, -50%)",
              width: 360, height: 360,
              background: "radial-gradient(circle, #dde8f8 0%, #c5d5ee 60%, transparent 100%)",
              borderRadius: "50%",
              pointerEvents: "none",
            }} />

            {/* Dark folder base — behind all cards */}
            <div style={{
              position: "absolute", bottom: 10, left: "50%",
              transform: "translateX(-50%)",
              width: 280, height: 140,
              background: "#1B3A6B",
              borderRadius: 16,
              boxShadow: "0 12px 36px rgba(27,58,107,0.4)",
              zIndex: 0,
            }} />

            {/* Document cards — each fully visible, spaced 108px apart */}
            {docCards.map((doc, i) => (
              <div key={doc.title} style={{
                position: "absolute",
                top: i * 108,
                left: "50%",
                transform: `translateX(calc(-50% + ${doc.offsetX}px)) rotate(${doc.rotate})`,
                width: 240,
                background: "#fff",
                borderRadius: 10,
                boxShadow: "0 4px 20px rgba(0,0,0,0.12)",
                padding: "12px 14px 13px",
                border: "1px solid #E2E8F0",
                zIndex: docCards.length - i,
              }}>
                {/* Header: seal + title + green tick — always visible */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 9, minWidth: 0 }}>
                    <div style={{ width: 26, height: 26, borderRadius: "50%", background: "#1B3A6B", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <div style={{ width: 11, height: 11, borderRadius: "50%", border: "2px solid #C9A84C" }} />
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 700, color: "#1B3A6B", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{doc.title}</span>
                  </div>
                  <div style={{ width: 22, height: 22, background: "#22C55E", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 11, fontWeight: 900, flexShrink: 0, marginLeft: 8 }}>✓</div>
                </div>
                {/* Paper content lines */}
                <div style={{ height: 4, background: "#CBD5E0", borderRadius: 2, width: "100%", marginBottom: 5 }} />
                <div style={{ height: 4, background: "#E8ECF0", borderRadius: 2, width: "80%", marginBottom: 5 }} />
                <div style={{ height: 4, background: "#E8ECF0", borderRadius: 2, width: "90%" }} />
                {/* Verified indicator */}
                <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 8 }}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#22C55E", flexShrink: 0 }} />
                  <span style={{ fontSize: 9, fontWeight: 700, color: "#22C55E", letterSpacing: 0.5 }}>VERIFIED</span>
                </div>
              </div>
            ))}

            {/* VERIFIED shield — bottom right corner */}
            <div style={{
              position: "absolute", bottom: 10, right: -8,
              background: "#1B3A6B", borderRadius: 12,
              padding: "12px 16px", textAlign: "center",
              boxShadow: "0 6px 24px rgba(27,58,107,0.5)",
              border: "2px solid #C9A84C",
              zIndex: docCards.length + 2,
            }}>
              <div style={{ fontSize: 20, marginBottom: 3 }}>🛡️</div>
              <div style={{ fontSize: 12, fontWeight: 800, color: "#C9A84C", letterSpacing: 1 }}>VERIFIED</div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS FEATURE BAR */}
      <div style={{ background: "#122952", padding: "36px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 0, maxWidth: 1000, margin: "0 auto" }}>
          {[
            { icon: "🏆", title: "9+ Years Experience", desc: "Deep expertise in Delhi property documentation & verification." },
            { icon: "🛡️", title: "100% Secure", desc: "Your documents are safe, private & used only for verification." },
            { icon: "⚡", title: "48-Hour Report", desc: "Get a detailed verification report within 48 hours of document submission." },
            { icon: "✅", title: "11 Critical Checks", desc: "We verify ownership, liens, approvals, dues, records & legal authenticity." },
          ].map((f, i) => (
            <div key={f.title} style={{
              padding: "24px 28px",
              borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.1)" : "none",
            }}>
              <div style={{ width: 48, height: 48, background: "rgba(255,255,255,0.12)", border: "1.5px solid rgba(255,255,255,0.25)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, marginBottom: 12 }}>
                {f.icon}
              </div>
              <div style={{ fontWeight: 700, fontSize: 15, color: "#fff", marginBottom: 6 }}>{f.title}</div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", lineHeight: 1.6 }}>{f.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* OUR SERVICES */}
      <section style={{ padding: "72px 24px", background: "#fff" }}>
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(24px, 4vw, 36px)", color: "#0D1B2A", marginBottom: 12 }}>Our Services</h2>
          <div style={{ width: 50, height: 3, background: "#C9A84C", borderRadius: 2, margin: "0 auto" }} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 32, maxWidth: 1000, margin: "0 auto" }}>
          {servicesList.map((s) => (
            <div key={s.name} style={{ display: "flex", gap: 18, alignItems: "flex-start" }}>
              <div style={{ width: 54, height: 54, minWidth: 54, background: "#F5F7FA", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, border: "1.5px solid #E2E8F0" }}>
                {s.icon}
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 15, color: "#0D1B2A", marginBottom: 6 }}>{s.name}</div>
                <div style={{ fontSize: 13, color: "#4A5568", lineHeight: 1.65, marginBottom: 10 }}>{s.desc}</div>
                <Link href="/services" style={{ fontSize: 13, fontWeight: 700, color: "#1B3A6B", textDecoration: "none" }}>Learn More →</Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ padding: "72px 24px", background: "#F5F7FA" }}>
        <div style={{ textAlign: "center", marginBottom: 52 }}>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(24px, 4vw, 36px)", color: "#0D1B2A", marginBottom: 12 }}>How It Works</h2>
          <div style={{ width: 50, height: 3, background: "#C9A84C", borderRadius: 2, margin: "0 auto" }} />
        </div>
        <div style={{ display: "flex", justifyContent: "center", alignItems: "flex-start", gap: 0, flexWrap: "wrap", maxWidth: 900, margin: "0 auto" }}>
          {howItWorks.map((step, i) => (
            <div key={step.title} style={{ display: "flex", alignItems: "flex-start", gap: 0 }}>
              <div style={{ textAlign: "center", width: 180, padding: "0 12px" }}>
                <div style={{ width: 36, height: 36, background: "#1B3A6B", color: "#C9A84C", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 15, margin: "0 auto 16px" }}>
                  {i + 1}
                </div>
                <div style={{ fontSize: 32, marginBottom: 12 }}>{step.icon}</div>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#0D1B2A", marginBottom: 8 }}>{step.title}</div>
                <div style={{ fontSize: 12, color: "#4A5568", lineHeight: 1.65 }}>{step.desc}</div>
              </div>
              {i < howItWorks.length - 1 && (
                <div style={{ color: "#C9A84C", fontSize: 22, fontWeight: 700, marginTop: 60, minWidth: 28, textAlign: "center" }}>→</div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* BOTTOM STATS BANNER */}
      <section style={{ background: "#122952", padding: "44px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 0, maxWidth: 900, margin: "0 auto" }}>
          {[
            { icon: "👥", num: "500+", label: "Properties Verified" },
            { icon: "🛡️", num: "9+", label: "Years Experience" },
            { icon: "⚡", num: "48hr", label: "Turnaround Time" },
            { icon: "⭐", num: "500+", label: "Happy Clients" },
          ].map((s, i) => (
            <div key={s.label} style={{
              textAlign: "center",
              padding: "16px 12px",
              borderLeft: i > 0 ? "1px solid rgba(255,255,255,0.1)" : "none",
            }}>
              <div style={{ fontSize: 22, marginBottom: 8 }}>{s.icon}</div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 32, fontWeight: 700, color: "#C9A84C" }}>{s.num}</div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.65)", marginTop: 4, fontWeight: 500 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section style={{ padding: "72px 24px", background: "#fff" }}>
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(24px, 4vw, 36px)", color: "#0D1B2A", marginBottom: 12 }}>What Our Clients Say</h2>
          <div style={{ width: 50, height: 3, background: "#C9A84C", borderRadius: 2, margin: "0 auto 10px" }} />
          <p style={{ fontSize: 14, color: "#4A5568", marginTop: 14 }}>Real clients, real results from Delhi NCR</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 24, maxWidth: 940, margin: "0 auto" }}>
          {[
            { name: "Rajesh Sharma", location: "Dwarka, Delhi", text: "PropClear ne meri property ka complete verification 40 ghante mein kar diya. DDA issues tha jo mujhe pata nahi tha — inki wajah se bada loss bachaya." },
            { name: "Priya Malhotra", location: "Noida, UP", text: "Ghar khareedne se pehle bahut darr tha. PropClear ki report ne sab clear kar diya. Professional aur fast service." },
            { name: "Anil Gupta", location: "Gurgaon, Haryana", text: "PM-UDAY regularization ke liye inse help li. Pure process mein haath thama — koi bhi document missing nahi hua." },
          ].map((t) => (
            <div key={t.name} style={{ background: "#F5F7FA", border: "1px solid #E2E8F0", borderRadius: 14, padding: "28px 24px" }}>
              <div style={{ color: "#C9A84C", fontSize: 16, marginBottom: 12 }}>★★★★★</div>
              <p style={{ fontSize: 14, color: "#4A5568", lineHeight: 1.8, marginBottom: 16, fontStyle: "italic" }}>"{t.text}"</p>
              <div style={{ fontWeight: 700, fontSize: 14, color: "#1B3A6B" }}>{t.name}</div>
              <div style={{ fontSize: 12, color: "#4A5568" }}>{t.location}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BANNER */}
      <section style={{ background: "linear-gradient(135deg, #122952, #1B3A6B)", padding: "60px 24px", textAlign: "center" }}>
        <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(22px, 4vw, 34px)", marginBottom: 14 }}>
          Ready to Verify Your Property?
        </h2>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 15, marginBottom: 32, maxWidth: 460, marginLeft: "auto", marginRight: "auto", lineHeight: 1.7 }}>
          Don't risk your hard-earned money. Get a complete verification report in 48 hours.
        </p>
        <Link href="/submit" style={{ background: "#C9A84C", color: "#0D1B2A", padding: "15px 36px", borderRadius: 8, fontWeight: 700, fontSize: 16, textDecoration: "none", display: "inline-block" }}>
          Get Started Today →
        </Link>
      </section>
    </div>
  );
}
