import { Link } from "wouter";

const WHATSAPP = "919354599207";
const EMAIL = "propclear.in@gmail.com";

export default function ContactInfo() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#1A1A2E" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #122952, #1B3A6B)", padding: "56px 24px 48px", textAlign: "center" }}>
        <div style={{ color: "#C9A84C", fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Get In Touch</div>
        <h1 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(26px, 4vw, 40px)", marginBottom: 14 }}>Contact PropClear</h1>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 16, maxWidth: 460, margin: "0 auto" }}>Koi bhi sawaal ho — WhatsApp, email, ya form ke through reach karein. Hum 2 ghante mein reply karte hain.</p>
      </div>

      {/* Contact Cards */}
      <section style={{ padding: "60px 24px", background: "#F5F7FA" }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>

          {/* Top row: 3 cards */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 24, marginBottom: 24 }}>
            {/* WhatsApp */}
            <a href={`https://wa.me/${WHATSAPP}?text=Hello! I want to know more about PropClear services.`} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
              <div style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 16, padding: "32px 28px", textAlign: "center", cursor: "pointer", transition: "box-shadow 0.2s, transform 0.2s" }}
                onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 8px 28px rgba(37,211,102,0.15)"; e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.borderColor = "#25D366"; }}
                onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.borderColor = "#E2E8F0"; }}
              >
                <div style={{ width: 60, height: 60, background: "#25D366", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontSize: 28 }}>
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="white">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </div>
                <div style={{ fontWeight: 700, fontSize: 16, color: "#1B3A6B", marginBottom: 6 }}>WhatsApp</div>
                <div style={{ fontSize: 15, color: "#25D366", fontWeight: 600, marginBottom: 4 }}>+91 93545 99207</div>
                <div style={{ fontSize: 12, color: "#4A5568" }}>Usually replies within 2 hours</div>
              </div>
            </a>

            {/* Email */}
            <a href={`mailto:${EMAIL}`} style={{ textDecoration: "none" }}>
              <div style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 16, padding: "32px 28px", textAlign: "center", cursor: "pointer", transition: "box-shadow 0.2s, transform 0.2s" }}
                onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 8px 28px rgba(27,58,107,0.12)"; e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.borderColor = "#C9A84C"; }}
                onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.borderColor = "#E2E8F0"; }}
              >
                <div style={{ width: 60, height: 60, background: "#1B3A6B", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontSize: 28 }}>
                  📧
                </div>
                <div style={{ fontWeight: 700, fontSize: 16, color: "#1B3A6B", marginBottom: 6 }}>Email</div>
                <div style={{ fontSize: 14, color: "#C9A84C", fontWeight: 600, marginBottom: 4 }}>{EMAIL}</div>
                <div style={{ fontSize: 12, color: "#4A5568" }}>For document submissions</div>
              </div>
            </a>

            {/* Working Hours */}
            <div style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 16, padding: "32px 28px", textAlign: "center" }}>
              <div style={{ width: 60, height: 60, background: "#1B3A6B", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontSize: 28 }}>
                ⏰
              </div>
              <div style={{ fontWeight: 700, fontSize: 16, color: "#1B3A6B", marginBottom: 6 }}>Working Hours</div>
              <div style={{ fontSize: 14, color: "#C9A84C", fontWeight: 600, marginBottom: 4 }}>Mon–Sat, 9am–7pm</div>
              <div style={{ fontSize: 12, color: "#4A5568" }}>WhatsApp available till 9pm</div>
            </div>
          </div>

          {/* Coverage Area */}
          <div style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 16, padding: "32px 36px", marginBottom: 24 }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 20, flexWrap: "wrap" }}>
              <div style={{ width: 52, height: 52, background: "#1B3A6B", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, minWidth: 52 }}>
                📍
              </div>
              <div style={{ flex: 1, minWidth: 200 }}>
                <div style={{ fontWeight: 700, fontSize: 17, color: "#1B3A6B", marginBottom: 8 }}>Service Coverage — Delhi NCR</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "8px 16px" }}>
                  {["Delhi (All Districts)", "Noida", "Greater Noida", "Gurgaon / Gurugram", "Faridabad", "Ghaziabad"].map((area) => (
                    <span key={area} style={{ background: "#F5F7FA", border: "1px solid #E2E8F0", borderRadius: 20, padding: "4px 14px", fontSize: 13, color: "#4A5568", fontWeight: 500 }}>
                      📌 {area}
                    </span>
                  ))}
                </div>
                <p style={{ fontSize: 13, color: "#4A5568", marginTop: 12, lineHeight: 1.6 }}>
                  DDA properties, MCD properties, unauthorized colonies, group housing — sabke liye.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Response Guarantee */}
          <div style={{ background: "#1B3A6B", borderRadius: 16, padding: "32px 36px", display: "flex", flexWrap: "wrap", gap: 24, alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <div style={{ color: "#C9A84C", fontWeight: 700, fontSize: 16, marginBottom: 8 }}>⚡ Quick Response Guarantee</div>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.8)", lineHeight: 1.7, maxWidth: 480 }}>
                Request submit karne ke <strong style={{ color: "#fff" }}>2 ghante</strong> ke andar hum aapko WhatsApp pe contact karenge — payment details aur confirmation ke saath. Report <strong style={{ color: "#fff" }}>48 ghante</strong> mein deliver hoti hai.
              </p>
            </div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <a href={`https://wa.me/${WHATSAPP}?text=Hello! I want to verify my property.`} target="_blank" rel="noopener noreferrer"
                style={{ background: "#25D366", color: "#fff", padding: "12px 22px", borderRadius: 8, fontWeight: 700, fontSize: 14, textDecoration: "none", display: "inline-block" }}>
                💬 WhatsApp Now
              </a>
              <Link href="/submit"
                style={{ background: "#C9A84C", color: "#122952", padding: "12px 22px", borderRadius: 8, fontWeight: 700, fontSize: 14, textDecoration: "none", display: "inline-block" }}>
                Submit Documents →
              </Link>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
}
