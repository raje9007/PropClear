import { useState } from "react";
import { Link } from "wouter";

export const blogPosts = [
  {
    slug: "dda-leasehold-to-freehold",
    title: "DDA Leasehold se Freehold Conversion: Complete Guide 2025",
    excerpt: "Delhi mein DDA property ka freehold conversion karna chahte hain? Poori process, required documents, aur common mistakes — sab kuch ek jagah.",
    category: "DDA Properties",
    date: "10 June 2025",
    readTime: "6 min read",
    image: "🏛️",
    content: `
DDA (Delhi Development Authority) ki properties originally leasehold hoti hain — matlab aap land ki ownership nahi rakhte, sirf lease par hoti hai. Lekin freehold conversion ke baad aap property ke full owner ban jaate hain.

**Freehold Conversion Kyun Zaroori Hai?**
- Freehold property ki resale value zyada hoti hai
- Home loan lena aasaan hota hai
- Mutation aur transfer simple ho jaata hai

**Required Documents:**
1. Original Conveyance Deed (CD)
2. Property Tax receipts (last 3 years)
3. No Dues Certificate from DDA
4. Identity proof of all owners
5. Possession letter

**Process:**
1. DDA website par application submit karein
2. Documents upload karein
3. Conversion fee pay karein (based on property size)
4. DDA verification (typically 30-60 days)
5. Freehold deed registration at Sub-Registrar office

**Common Mistakes to Avoid:**
- Incomplete document set — rejection ka sabse bada reason
- Unpaid property tax — application hold ho jaati hai
- Missing co-owner signatures — all owners ka consent zaroori hai

PropClear aapke documents pre-check kar sakta hai before you apply — saving time and rejection risk.
    `,
  },
  {
    slug: "property-verification-before-buying",
    title: "Ghar Khareedne Se Pehle 11 Cheezein Zaroor Check Karein",
    excerpt: "Property fraud se bachna hai? Ye 11-point checklist follow karo. Delhi NCR mein property khareedne waalon ke liye essential guide.",
    category: "Buyer's Guide",
    date: "28 May 2025",
    readTime: "8 min read",
    image: "🔍",
    content: `
Delhi NCR mein property khareedna ek bada financial decision hai. Neeche diye 11 points check karo before you sign anything.

**1. Title Deed Verification**
Check karo ki seller actual owner hai. Title chain clear honi chahiye.

**2. Encumbrance Certificate (EC)**
EC se pata chalega ki property pe koi loan ya mortgage toh nahi hai.

**3. CERSAI Check**
Central Registry mein check karo ki koi charge registered toh nahi.

**4. eCourts Litigation**
Property pe koi court case pending toh nahi — DORIS aur eCourts se verify karein.

**5. DDA/MCD Approval**
Building plan approved hai? Unauthorized construction toh nahi?

**6. Mutation Status**
Property owner ka naam government records mein update hua hai ya nahi?

**7. Property Tax Dues**
Seller ne saare property taxes pay kiye hain? Arrears buyer pe aate hain.

**8. Society NOC**
Agar apartment hai toh housing society se NOC zaroori hai.

**9. RERA Registration**
New project hai toh RERA registered hona chahiye.

**10. Occupation Certificate (OC)**
Building complete hai aur OC mila hai? Bina OC ke loan nahi milta.

**11. Power of Attorney Validity**
Agar seller POA pe kaam kar raha hai toh POA valid aur registered hona chahiye.

PropClear ka Complete Property Report inn 11 points mein se sabse critical ones cover karta hai government portals ke through.
    `,
  },
  {
    slug: "pm-uday-scheme-guide",
    title: "PM-UDAY Scheme Kya Hai? Delhi ki Unauthorized Colonies ke Liye Complete Guide",
    excerpt: "PM-UDAY scheme ke through Delhi ki 1,731 unauthorized colonies ke residents property rights pa sakte hain. Eligibility, process aur documents — sab yahan.",
    category: "PM-UDAY",
    date: "15 May 2025",
    readTime: "7 min read",
    image: "🏠",
    content: `
PM-UDAY (Pradhan Mantri Unauthorized Colonies in Delhi Awas Adhikar Yojana) ek central government scheme hai jo 2019 mein launch hui. Is scheme ke through 40 lakh se zyada Delhi residents unauthorized colonies mein property rights pa sakte hain.

**Kya Hai PM-UDAY?**
Delhi mein approximately 1,731 unauthorized colonies hain jahan log decades se reh rahe hain lekin unke paas formal property rights nahi hain. PM-UDAY in residents ko conveyance deed ya authorization letter deta hai.

**Eligibility:**
- Aap authorized colony mein nahi rehte
- Property 2014 se pehle se exist kar rahi hai
- Continuous residence ka proof hai
- DDA/govt. land pe property nahi hai

**Required Documents:**
1. Sale deed ya agreement to sell
2. Property tax receipts
3. Electricity/water bills (residence proof)
4. Aadhaar card
5. Passport size photographs
6. Survey/khasra number

**Process:**
1. Online registration at PM-UDAY portal
2. Documents upload
3. Physical verification by DDA officials
4. Authorization letter / Conveyance Deed issuance

**Timeline:** Process mein typically 6-18 months lagte hain depending on colony aur case complexity.

PropClear PM-UDAY End-to-End service mein hum aapke saath har step pe hain — documentation se lekar approval tak.
    `,
  },
  {
    slug: "mutation-name-transfer-delhi",
    title: "Mutation (Dakhil Kharij) Kaise Karte Hain? Delhi/NCR Property Name Transfer Guide",
    excerpt: "Property khareedne ke baad mutation karwana zaroori hai. Delhi aur NCR mein mutation process, documents aur timeline — poori jankari.",
    category: "Mutation",
    date: "5 May 2025",
    readTime: "5 min read",
    image: "📝",
    content: `
Property khareedne ke baad sabse zaroori kaam hai mutation — yaani government records mein apna naam update karana.

**Mutation Kyun Zaroori Hai?**
- Property tax aapke naam aani chahiye
- Future resale mein problems na hon
- Home loan refinancing ke liye
- Legal ownership proof ke liye

**Delhi Mutation Process (MCD/NDMC):**
1. MCD online portal par application
2. Sale deed, old property tax records upload
3. Field verification by MCD official
4. Objection period (typically 30 days)
5. Mutation order issuance

**DDA Property Mutation:**
DDA properties ke liye alag process hai — DDA office mein direct application, aur timeline typically 60-90 days.

**Required Documents:**
- Registered Sale Deed
- Previous property tax receipt
- Identity proof (Aadhaar/PAN)
- Property address proof
- Application form

**Common Issues:**
- Boundary disputes causing delay
- Unpaid dues on previous owner
- Missing documents in original registration

PropClear mutation status check kar sakta hai aur aapko guide kar sakta hai agar koi issue ho.
    `,
  },
];

function BlogCard({ post, full = false }: { post: typeof blogPosts[0]; full?: boolean }) {
  return (
    <Link href={`/blog/${post.slug}`} style={{ textDecoration: "none", display: "block" }}>
      <div style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 14, overflow: "hidden", transition: "box-shadow 0.2s, transform 0.2s", cursor: "pointer" }}
        onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 8px 28px rgba(27,58,107,0.12)"; e.currentTarget.style.transform = "translateY(-4px)"; }}
        onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; e.currentTarget.style.transform = "translateY(0)"; }}
      >
        <div style={{ background: "linear-gradient(135deg, #1B3A6B, #2A5298)", padding: "32px 28px", fontSize: 48, textAlign: "center" }}>
          {post.image}
        </div>
        <div style={{ padding: "24px 24px 28px" }}>
          <div style={{ display: "flex", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
            <span style={{ background: "rgba(201,168,76,0.12)", color: "#C9A84C", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 8 }}>{post.category}</span>
            <span style={{ fontSize: 11, color: "#4A5568" }}>{post.date} · {post.readTime}</span>
          </div>
          <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, color: "#1B3A6B", marginBottom: 10, lineHeight: 1.4 }}>{post.title}</h3>
          <p style={{ fontSize: 13, color: "#4A5568", lineHeight: 1.7, marginBottom: 16 }}>{post.excerpt}</p>
          <span style={{ fontSize: 13, color: "#1B3A6B", fontWeight: 700 }}>Read More →</span>
        </div>
      </div>
    </Link>
  );
}

export function BlogPostPage({ slug }: { slug: string }) {
  const post = blogPosts.find((p) => p.slug === slug);
  if (!post) return (
    <div style={{ padding: "80px 24px", textAlign: "center", fontFamily: "'Inter', sans-serif" }}>
      <h2 style={{ color: "#1B3A6B" }}>Post not found</h2>
      <Link href="/blog" style={{ color: "#C9A84C" }}>← Back to Blog</Link>
    </div>
  );

  const paragraphs = post.content.trim().split("\n\n");

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#1A1A2E" }}>
      <div style={{ background: "linear-gradient(135deg, #122952, #1B3A6B)", padding: "56px 24px 48px" }}>
        <div style={{ maxWidth: 740, margin: "0 auto" }}>
          <Link href="/blog" style={{ color: "#C9A84C", textDecoration: "none", fontSize: 13, fontWeight: 600 }}>← Back to Blog</Link>
          <div style={{ display: "flex", gap: 10, marginTop: 16, marginBottom: 14, flexWrap: "wrap" }}>
            <span style={{ background: "rgba(201,168,76,0.15)", color: "#C9A84C", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 8 }}>{post.category}</span>
            <span style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>{post.date} · {post.readTime}</span>
          </div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(22px, 4vw, 36px)", lineHeight: 1.3 }}>{post.title}</h1>
        </div>
      </div>

      <section style={{ padding: "48px 24px 64px", background: "#fff" }}>
        <div style={{ maxWidth: 740, margin: "0 auto" }}>
          <p style={{ fontSize: 16, color: "#4A5568", lineHeight: 1.8, marginBottom: 28, fontStyle: "italic", borderLeft: "3px solid #C9A84C", paddingLeft: 16 }}>{post.excerpt}</p>
          {paragraphs.map((para, i) => {
            if (para.startsWith("**") && para.endsWith("**")) {
              return <h3 key={i} style={{ fontSize: 17, fontWeight: 700, color: "#1B3A6B", margin: "24px 0 8px" }}>{para.replace(/\*\*/g, "")}</h3>;
            }
            if (para.match(/^\d+\./m)) {
              return (
                <ul key={i} style={{ paddingLeft: 20, marginBottom: 16 }}>
                  {para.split("\n").map((line, j) => (
                    <li key={j} style={{ fontSize: 14, color: "#4A5568", lineHeight: 1.8, marginBottom: 4 }}>
                      {line.replace(/^\d+\.\s/, "").replace(/\*\*(.*?)\*\*/g, "$1")}
                    </li>
                  ))}
                </ul>
              );
            }
            if (para.startsWith("- ")) {
              return (
                <ul key={i} style={{ paddingLeft: 20, marginBottom: 16 }}>
                  {para.split("\n").map((line, j) => (
                    <li key={j} style={{ fontSize: 14, color: "#4A5568", lineHeight: 1.8, marginBottom: 4 }}>
                      {line.replace(/^- /, "").replace(/\*\*(.*?)\*\*/g, "$1")}
                    </li>
                  ))}
                </ul>
              );
            }
            return <p key={i} style={{ fontSize: 15, color: "#4A5568", lineHeight: 1.85, marginBottom: 18 }} dangerouslySetInnerHTML={{ __html: para.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>") }} />;
          })}

          <div style={{ background: "#F5F7FA", border: "1px solid #E2E8F0", borderLeft: "4px solid #C9A84C", borderRadius: 10, padding: "24px 24px", marginTop: 36 }}>
            <h4 style={{ fontWeight: 700, color: "#1B3A6B", marginBottom: 8 }}>PropClear se Help Chahiye?</h4>
            <p style={{ fontSize: 14, color: "#4A5568", lineHeight: 1.7, marginBottom: 16 }}>Apni property ka verification karwana chahte hain? Hum 48 ghante mein detailed report dete hain.</p>
            <Link href="/contact" style={{ background: "#1B3A6B", color: "#fff", padding: "10px 22px", borderRadius: 8, fontWeight: 700, fontSize: 14, textDecoration: "none", display: "inline-block" }}>
              Submit Your Request →
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default function Blog() {
  const [selectedCat, setSelectedCat] = useState("All");
  const categories = ["All", ...Array.from(new Set(blogPosts.map((p) => p.category)))];
  const filtered = selectedCat === "All" ? blogPosts : blogPosts.filter((p) => p.category === selectedCat);

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#1A1A2E" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #122952, #1B3A6B)", padding: "56px 24px 48px", textAlign: "center" }}>
        <div style={{ color: "#C9A84C", fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Knowledge Base</div>
        <h1 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(26px, 4vw, 40px)", marginBottom: 14 }}>PropClear Blog</h1>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 16, maxWidth: 500, margin: "0 auto" }}>Delhi NCR property ke baare mein guides, tips, aur latest updates — Hindi aur English mein.</p>
      </div>

      <section style={{ padding: "48px 24px 64px", background: "#F5F7FA" }}>
        {/* Category filter */}
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center", marginBottom: 40 }}>
          {categories.map((cat) => (
            <button key={cat} onClick={() => setSelectedCat(cat)} style={{ padding: "8px 18px", borderRadius: 20, border: "1.5px solid", borderColor: selectedCat === cat ? "#1B3A6B" : "#E2E8F0", background: selectedCat === cat ? "#1B3A6B" : "#fff", color: selectedCat === cat ? "#fff" : "#4A5568", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
              {cat}
            </button>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 24, maxWidth: 1000, margin: "0 auto" }}>
          {filtered.map((post) => (
            <BlogCard key={post.slug} post={post} />
          ))}
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section style={{ background: "#1B3A6B", padding: "48px 24px", textAlign: "center" }}>
        <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(20px, 3vw, 28px)", marginBottom: 12 }}>Naye Articles Miss Na Karein</h2>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 15, marginBottom: 24, maxWidth: 420, marginLeft: "auto", marginRight: "auto" }}>Property ke baare mein latest guides aur updates ke liye WhatsApp par connect karein.</p>
        <a href="https://wa.me/919354599207?text=Hi! I want to follow PropClear property updates." target="_blank" rel="noopener noreferrer" style={{ background: "#25D366", color: "#fff", padding: "13px 30px", borderRadius: 8, fontWeight: 700, fontSize: 15, textDecoration: "none", display: "inline-block" }}>
          💬 WhatsApp pe Join Karein
        </a>
      </section>
    </div>
  );
}
