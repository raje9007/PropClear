import { Link } from "wouter";

const plans = [
  {
    icon: "💬",
    name: "Property Consultation",
    price: "₹499",
    unit: "/ session",
    turnaround: "Same Day Response",
    desc: "Expert guidance before buying or selling. Understand what documents are needed, what risks exist, and what to check before proceeding.",
    includes: [
      "30-minute expert consultation (phone/WhatsApp)",
      "Checklist of documents required for your transaction",
      "Overview of common red flags for your area",
      "Guidance on next steps",
    ],
    popular: false,
    color: "#4A5568",
  },
  {
    icon: "📄",
    name: "Document Check",
    price: "₹999",
    unit: "/ report",
    turnaround: "Report in 48 Hours",
    desc: "Basic verification of your property documents — title deed, Encumbrance Certificate, mutation status, and court case check.",
    includes: [
      "Title deed authenticity check",
      "Encumbrance Certificate (EC) verification",
      "Mutation / Khatoni status",
      "eCourts litigation check",
      "Written summary report (PDF)",
    ],
    popular: false,
    color: "#1B3A6B",
  },
  {
    icon: "🔍",
    name: "Complete Property Report",
    price: "₹1,999",
    unit: "/ report",
    turnaround: "Report in 48 Hours",
    desc: "11-point comprehensive check — DORIS, NGDRS, CERSAI, eCourts, DDA portal, MCD — all covered. Full risk report with findings.",
    includes: [
      "All Document Check items",
      "DDA portal check (leasehold/freehold status)",
      "DORIS & NGDRS registry check",
      "CERSAI mortgage/charge check",
      "MCD tax status verification",
      "Unauthorized colony status check",
      "11-point risk scoring",
      "Detailed PDF report with recommendations",
      "WhatsApp follow-up Q&A (48 hrs)",
    ],
    popular: true,
    color: "#C9A84C",
  },
  {
    icon: "🏠",
    name: "PM-UDAY End-to-End",
    price: "₹15,000",
    unit: "/ case",
    turnaround: "Full Handholding Support",
    desc: "Unauthorized colony regularization — full support from application to approval under Delhi Government's latest PM-UDAY guidelines.",
    includes: [
      "Eligibility check for PM-UDAY scheme",
      "Complete document collection guidance",
      "Application form preparation & filing",
      "Liaison with DDA / Revenue department",
      "Status tracking & follow-ups",
      "Certificate of regularization support",
      "End-to-end handholding till approval",
    ],
    popular: false,
    color: "#2A5298",
  },
];

const comparisons = [
  { feature: "Title Deed Check", consultation: false, docCheck: true, complete: true, pmuday: true },
  { feature: "EC / Encumbrance", consultation: false, docCheck: true, complete: true, pmuday: true },
  { feature: "eCourts Litigation", consultation: false, docCheck: true, complete: true, pmuday: true },
  { feature: "DDA Portal Check", consultation: false, docCheck: false, complete: true, pmuday: true },
  { feature: "CERSAI Mortgage Check", consultation: false, docCheck: false, complete: true, pmuday: true },
  { feature: "DORIS / NGDRS", consultation: false, docCheck: false, complete: true, pmuday: true },
  { feature: "MCD Tax Verification", consultation: false, docCheck: false, complete: true, pmuday: true },
  { feature: "11-Point Risk Score", consultation: false, docCheck: false, complete: true, pmuday: false },
  { feature: "PDF Report", consultation: false, docCheck: true, complete: true, pmuday: true },
  { feature: "PM-UDAY Filing", consultation: false, docCheck: false, complete: false, pmuday: true },
  { feature: "Govt. Liaison", consultation: false, docCheck: false, complete: false, pmuday: true },
];

export default function Services() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#1A1A2E" }}>
      {/* Page Header */}
      <div style={{ background: "linear-gradient(135deg, #122952, #1B3A6B)", padding: "56px 24px 48px", textAlign: "center" }}>
        <div style={{ color: "#C9A84C", fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Our Plans</div>
        <h1 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(26px, 4vw, 40px)", marginBottom: 14 }}>Verification Plans & Pricing</h1>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 16, maxWidth: 480, margin: "0 auto" }}>Choose the right plan for your property transaction. Every plan includes WhatsApp delivery.</p>
      </div>

      {/* Plans */}
      <section style={{ padding: "60px 24px", background: "#fff" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24, maxWidth: 1040, margin: "0 auto" }}>
          {plans.map((plan) => (
            <div key={plan.name} style={{ border: plan.popular ? "2px solid #C9A84C" : "1.5px solid #E2E8F0", borderRadius: 16, padding: "32px 26px", position: "relative", background: "#fff", boxShadow: plan.popular ? "0 8px 32px rgba(201,168,76,0.15)" : "none" }}>
              {plan.popular && (
                <div style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: "#C9A84C", color: "#122952", fontSize: 11, fontWeight: 700, padding: "5px 16px", borderRadius: 12, whiteSpace: "nowrap" }}>
                  ⭐ Most Popular
                </div>
              )}
              <div style={{ fontSize: 32, marginBottom: 14 }}>{plan.icon}</div>
              <h3 style={{ fontWeight: 700, fontSize: 18, color: "#1B3A6B", marginBottom: 8 }}>{plan.name}</h3>
              <p style={{ fontSize: 13, color: "#4A5568", lineHeight: 1.65, marginBottom: 18 }}>{plan.desc}</p>
              <div style={{ fontSize: 28, fontWeight: 700, color: "#C9A84C", marginBottom: 4 }}>
                {plan.price} <span style={{ fontSize: 14, color: "#4A5568", fontWeight: 400 }}>{plan.unit}</span>
              </div>
              <div style={{ fontSize: 12, color: "#2D7D46", fontWeight: 600, marginBottom: 22 }}>⚡ {plan.turnaround}</div>

              <div style={{ borderTop: "1px solid #E2E8F0", paddingTop: 18, marginBottom: 24 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: "#1B3A6B", marginBottom: 12, textTransform: "uppercase", letterSpacing: 0.5 }}>What's Included</div>
                {plan.includes.map((item) => (
                  <div key={item} style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 8 }}>
                    <span style={{ color: "#2D7D46", fontSize: 14, marginTop: 1 }}>✓</span>
                    <span style={{ fontSize: 13, color: "#4A5568", lineHeight: 1.5 }}>{item}</span>
                  </div>
                ))}
              </div>

              <Link href="/contact" style={{ display: "block", textAlign: "center", background: plan.popular ? "#C9A84C" : "#1B3A6B", color: plan.popular ? "#122952" : "#fff", padding: "12px 20px", borderRadius: 8, fontWeight: 700, fontSize: 14, textDecoration: "none" }}>
                Get This Plan →
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Comparison Table */}
      <section style={{ padding: "48px 24px 64px", background: "#F5F7FA" }}>
        <h2 style={{ textAlign: "center", fontFamily: "'Playfair Display', serif", fontSize: "clamp(22px, 3vw, 30px)", color: "#1B3A6B", marginBottom: 36 }}>Plan Comparison</h2>
        <div style={{ maxWidth: 860, margin: "0 auto", overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14, background: "#fff", borderRadius: 12, overflow: "hidden", boxShadow: "0 2px 16px rgba(27,58,107,0.07)" }}>
            <thead>
              <tr style={{ background: "#1B3A6B", color: "#fff" }}>
                <th style={{ padding: "14px 18px", textAlign: "left", fontWeight: 600 }}>Feature</th>
                {["Consultation", "Doc Check", "Complete Report", "PM-UDAY"].map((h) => (
                  <th key={h} style={{ padding: "14px 12px", textAlign: "center", fontWeight: 600, fontSize: 12 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {comparisons.map((row, i) => (
                <tr key={row.feature} style={{ background: i % 2 === 0 ? "#fff" : "#F5F7FA" }}>
                  <td style={{ padding: "12px 18px", color: "#4A5568", fontWeight: 500 }}>{row.feature}</td>
                  {[row.consultation, row.docCheck, row.complete, row.pmuday].map((val, j) => (
                    <td key={j} style={{ padding: "12px", textAlign: "center" }}>
                      {val ? <span style={{ color: "#2D7D46", fontSize: 18 }}>✓</span> : <span style={{ color: "#CBD5E0", fontSize: 16 }}>—</span>}
                    </td>
                  ))}
                </tr>
              ))}
              <tr style={{ background: "#1B3A6B" }}>
                <td style={{ padding: "14px 18px", color: "#C9A84C", fontWeight: 700 }}>Price</td>
                {["₹499", "₹999", "₹1,999", "₹15,000"].map((p) => (
                  <td key={p} style={{ padding: "14px 12px", textAlign: "center", color: "#C9A84C", fontWeight: 700, fontSize: 15 }}>{p}</td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* CTA */}
      <section style={{ background: "#1B3A6B", padding: "48px 24px", textAlign: "center" }}>
        <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(20px, 3vw, 28px)", marginBottom: 12 }}>Not Sure Which Plan?</h2>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 15, marginBottom: 24, maxWidth: 420, marginLeft: "auto", marginRight: "auto" }}>Start with a ₹499 consultation and we'll guide you to the right plan for your case.</p>
        <Link href="/contact" style={{ background: "#C9A84C", color: "#122952", padding: "13px 30px", borderRadius: 8, fontWeight: 700, fontSize: 15, textDecoration: "none", display: "inline-block" }}>
          Talk to an Expert →
        </Link>
      </section>
    </div>
  );
}
