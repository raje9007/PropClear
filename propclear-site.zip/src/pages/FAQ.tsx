import { useState } from "react";
import { Link } from "wouter";

const faqs = [
  {
    category: "About PropClear",
    items: [
      { q: "PropClear kya hai?", a: "PropClear ek Delhi NCR property document verification service hai. Hum aapke property documents ko government portals jaise DDA, DORIS, CERSAI, MCD, aur eCourts pe check karte hain aur ek detailed report dete hain — taaki aap property khareedne, bechne ya transfer karne se pehle fully informed rahein." },
      { q: "Kya PropClear ek legal service hai?", a: "Nahi. PropClear reports ek due diligence tool hain jo publicly available government records par based hain. Ye ek legal opinion nahi hai. Complex cases ke liye, ek property advocate se legal review lena advisable hai. Hum aapko risks batate hain, legal advice nahi dete." },
      { q: "PropClear ka experience kitna hai?", a: "Hamare team ko Delhi NCR property documents aur DDA processes ka 9+ saal ka hands-on experience hai — leasehold conversion, mutation, freehold, aur unauthorized colony regularization sabme." },
    ]
  },
  {
    category: "Process & Timing",
    items: [
      { q: "Report kitne time mein milegi?", a: "Document Check aur Complete Property Report dono 48 ghante ke andar deliver ho jaati hain payment confirmation ke baad. Property Consultation same day hota hai. PM-UDAY service ek longer process hai aur timeline case ke upar depend karti hai." },
      { q: "Office visit karna hoga?", a: "Bilkul nahi. Poora process online aur WhatsApp par hota hai. Documents WhatsApp ya email se bhejo, hum verify karte hain, aur report WhatsApp pe bhejte hain." },
      { q: "Payment kaise karein?", a: "Payment link aapko WhatsApp pe milega. UPI (GPay, PhonePe, Paytm), NEFT/IMPS bank transfer — koi bhi method chalega. Payment confirm hone ke baad verification shuru hoti hai." },
      { q: "Kya main track kar sakta hoon ki verification chal rahi hai?", a: "Haan, hum aapko WhatsApp pe updates dete hain. Agar koi document missing hoga ya koi issue hoga to hum immediately contact karenge." },
    ]
  },
  {
    category: "Documents & Privacy",
    items: [
      { q: "Mujhe konse documents dene honge?", a: "Yeh depend karta hai plan aur transaction type par. Generally: Sale Deed / Title Deed, Encumbrance Certificate (EC), Property Card ya Khatoni, aur any existing NOC ya mutation documents. Consultation mein hum aapko exact list denge." },
      { q: "Mere documents safe hain?", a: "Haan, bilkul. Aapke documents sirf verification ke liye use hote hain aur kisi third party se share nahi kiye jaate. Verification complete hone ke baad documents securely delete kar diye jaate hain." },
      { q: "Kya PDF documents chalenge?", a: "Haan, PDF, JPG, aur PNG sab chalte hain. Max 10MB per file. Agar documents physically hain, toh clear photo bhi chal sakti hai." },
    ]
  },
  {
    category: "Services & Coverage",
    items: [
      { q: "Kaunse areas cover karte ho?", a: "Hum puri Delhi NCR cover karte hain — Delhi (all districts), Noida, Greater Noida, Gurgaon/Gurugram, Faridabad, Ghaziabad. DDA properties, MCD properties, unauthorized colonies, group housing — sabke liye." },
      { q: "PM-UDAY scheme kya hai?", a: "PM-UDAY (Pradhan Mantri Unauthorized Colonies in Delhi Awas Adhikar Yojana) ek Delhi government scheme hai jo unauthorized colonies mein rehne waale logon ko property rights deti hai. Agar aapki colony unauthorized hai, toh ye scheme aapko ownership rights de sakti hai." },
      { q: "Kya hum loan ke liye bhi property verify kar sakte hain?", a: "Haan, Home Loan ke liye property verification ek common use case hai. Banks apni khud ki verification karti hain, lekin PropClear ki report aapko pehle se potential issues identify karne mein help karti hai — jisse loan rejection ka risk kam hota hai." },
      { q: "Report mein kya hota hai?", a: "Complete Property Report mein hota hai: property ownership chain, encumbrance status, court cases (if any), DDA lease status, CERSAI mortgage charges, mutation status, aur ek overall risk rating with recommendations. Report PDF format mein WhatsApp pe milti hai." },
    ]
  }
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ borderBottom: "1px solid #E2E8F0" }}>
      <button
        onClick={() => setOpen(!open)}
        style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 0", background: "none", border: "none", cursor: "pointer", textAlign: "left", gap: 16 }}
      >
        <span style={{ fontSize: 15, fontWeight: 600, color: "#1B3A6B", lineHeight: 1.5 }}>{q}</span>
        <span style={{ fontSize: 20, color: "#C9A84C", minWidth: 24, fontWeight: 300, transform: open ? "rotate(45deg)" : "none", transition: "transform 0.2s" }}>+</span>
      </button>
      {open && (
        <div style={{ paddingBottom: 18 }}>
          <p style={{ fontSize: 14, color: "#4A5568", lineHeight: 1.8 }}>{a}</p>
        </div>
      )}
    </div>
  );
}

export default function FAQ() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#1A1A2E" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #122952, #1B3A6B)", padding: "56px 24px 48px", textAlign: "center" }}>
        <div style={{ color: "#C9A84C", fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>FAQ</div>
        <h1 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(26px, 4vw, 40px)", marginBottom: 14 }}>Frequently Asked Questions</h1>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 16, maxWidth: 500, margin: "0 auto" }}>Property verification ke baare mein sabse common sawaalon ke jawab yahan hain.</p>
      </div>

      {/* FAQ Sections */}
      <section style={{ padding: "60px 24px", background: "#fff" }}>
        <div style={{ maxWidth: 760, margin: "0 auto" }}>
          {faqs.map((section) => (
            <div key={section.category} style={{ marginBottom: 48 }}>
              <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#1B3A6B", marginBottom: 4, paddingBottom: 12, borderBottom: "2px solid #C9A84C", display: "inline-block" }}>
                {section.category}
              </h2>
              <div style={{ marginTop: 20 }}>
                {section.items.map((item) => (
                  <FAQItem key={item.q} q={item.q} a={item.a} />
                ))}
              </div>
            </div>
          ))}

          {/* Still have questions */}
          <div style={{ background: "#F5F7FA", border: "1px solid #E2E8F0", borderLeft: "4px solid #C9A84C", borderRadius: 12, padding: "28px 28px", marginTop: 16 }}>
            <h3 style={{ fontWeight: 700, fontSize: 17, color: "#1B3A6B", marginBottom: 8 }}>Aur koi sawaal hai?</h3>
            <p style={{ fontSize: 14, color: "#4A5568", lineHeight: 1.7, marginBottom: 18 }}>
              Agar aapka sawaal yahan nahi mila, toh seedha WhatsApp pe poochh saktey hain — hum usually 2 ghante ke andar reply karte hain.
            </p>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <Link href="/contact" style={{ background: "#1B3A6B", color: "#fff", padding: "11px 22px", borderRadius: 8, fontWeight: 700, fontSize: 14, textDecoration: "none", display: "inline-block" }}>
                Submit a Request
              </Link>
              <a href="https://wa.me/919354599207" target="_blank" rel="noopener noreferrer" style={{ background: "#25D366", color: "#fff", padding: "11px 22px", borderRadius: 8, fontWeight: 700, fontSize: 14, textDecoration: "none", display: "inline-block" }}>
                💬 WhatsApp Us
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
