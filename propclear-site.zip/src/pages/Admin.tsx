import { useState, useEffect } from "react";

type RequestRecord = {
  id: number;
  name: string;
  phone: string;
  email?: string | null;
  address: string;
  service: string;
  transaction: string;
  concern?: string | null;
  status: string;
  createdAt: string;
};

const STATUS_COLORS: Record<string, { bg: string; color: string; label: string }> = {
  new:          { bg: "#EBF8FF", color: "#2B6CB0", label: "🆕 New" },
  in_progress:  { bg: "#FFFBEB", color: "#B7791F", label: "⏳ In Progress" },
  completed:    { bg: "#F0FFF4", color: "#276749", label: "✅ Completed" },
  cancelled:    { bg: "#FFF5F5", color: "#C53030", label: "❌ Cancelled" },
};

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function Admin() {
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [requests, setRequests] = useState<RequestRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");
  const [updating, setUpdating] = useState<number | null>(null);

  async function login(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${BASE}/api/admin/requests`, {
        headers: { "x-admin-password": password },
      });
      if (res.status === 401) { setError("Wrong password"); setLoading(false); return; }
      const data = await res.json();
      setRequests(data);
      setLoggedIn(true);
    } catch {
      setError("Connection error — try again");
    }
    setLoading(false);
  }

  async function fetchRequests() {
    const res = await fetch(`${BASE}/api/admin/requests`, {
      headers: { "x-admin-password": password },
    });
    if (res.ok) setRequests(await res.json());
  }

  async function updateStatus(id: number, status: string) {
    setUpdating(id);
    await fetch(`${BASE}/api/admin/requests/${id}/status`, {
      method: "PATCH",
      headers: { "content-type": "application/json", "x-admin-password": password },
      body: JSON.stringify({ status }),
    });
    await fetchRequests();
    setUpdating(null);
  }

  useEffect(() => {
    if (loggedIn) {
      const interval = setInterval(fetchRequests, 30000);
      return () => clearInterval(interval);
    }
  }, [loggedIn]);

  const filtered = filter === "all" ? requests : requests.filter((r) => r.status === filter);
  const counts = requests.reduce((acc, r) => { acc[r.status] = (acc[r.status] || 0) + 1; return acc; }, {} as Record<string, number>);

  if (!loggedIn) {
    return (
      <div style={{ minHeight: "100vh", background: "#F5F7FA", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter', sans-serif" }}>
        <div style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 16, padding: "48px 40px", width: "100%", maxWidth: 380, boxShadow: "0 8px 32px rgba(27,58,107,0.1)" }}>
          <div style={{ display: "flex", justifyContent: "center", marginBottom: 20 }}>
            <img src="/propclear-logo.jpg" alt="PropClear" style={{ width: 64, height: 64, borderRadius: "50%", objectFit: "cover", border: "2px solid #C9A84C" }} />
          </div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#1B3A6B", textAlign: "center", marginBottom: 6 }}>Admin Panel</h1>
          <p style={{ fontSize: 13, color: "#4A5568", textAlign: "center", marginBottom: 28 }}>PropClear — Requests Dashboard</p>
          <form onSubmit={login}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Admin Password</label>
            <input
              type="password"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #E2E8F0", borderRadius: 8, fontSize: 14, fontFamily: "'Inter', sans-serif", outline: "none", boxSizing: "border-box" }}
              required
            />
            {error && <p style={{ fontSize: 12, color: "#E53E3E", marginTop: 6 }}>{error}</p>}
            <button type="submit" disabled={loading} style={{ marginTop: 18, width: "100%", background: "#1B3A6B", color: "#fff", border: "none", padding: 13, borderRadius: 8, fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
              {loading ? "Checking…" : "Login →"}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#F5F7FA", fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div style={{ background: "#1B3A6B", padding: "16px 28px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <img src="/propclear-logo.jpg" alt="" style={{ width: 36, height: 36, borderRadius: "50%", objectFit: "cover", border: "2px solid #C9A84C" }} />
          <span style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: 18 }}>Prop<span style={{ color: "#C9A84C" }}>Clear</span> — Admin</span>
        </div>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <button onClick={fetchRequests} style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: "7px 14px", borderRadius: 6, cursor: "pointer", fontSize: 13, fontFamily: "'Inter', sans-serif" }}>
            🔄 Refresh
          </button>
          <button onClick={() => setLoggedIn(false)} style={{ background: "transparent", border: "1px solid rgba(255,255,255,0.3)", color: "rgba(255,255,255,0.7)", padding: "7px 14px", borderRadius: 6, cursor: "pointer", fontSize: 13, fontFamily: "'Inter', sans-serif" }}>
            Logout
          </button>
        </div>
      </div>

      <div style={{ padding: "28px 24px", maxWidth: 1100, margin: "0 auto" }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 16, marginBottom: 28 }}>
          {[
            { label: "Total", count: requests.length, color: "#1B3A6B", bg: "#EBF4FF" },
            { label: "New", count: counts["new"] || 0, color: "#2B6CB0", bg: "#EBF8FF" },
            { label: "In Progress", count: counts["in_progress"] || 0, color: "#B7791F", bg: "#FFFBEB" },
            { label: "Completed", count: counts["completed"] || 0, color: "#276749", bg: "#F0FFF4" },
          ].map((s) => (
            <div key={s.label} style={{ background: s.bg, border: "1px solid #E2E8F0", borderRadius: 12, padding: "18px 20px" }}>
              <div style={{ fontSize: 28, fontWeight: 700, color: s.color }}>{s.count}</div>
              <div style={{ fontSize: 12, color: "#4A5568", marginTop: 2, fontWeight: 500 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Filter tabs */}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
          {["all", "new", "in_progress", "completed", "cancelled"].map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              style={{ padding: "7px 16px", borderRadius: 20, border: "1.5px solid", borderColor: filter === f ? "#1B3A6B" : "#E2E8F0", background: filter === f ? "#1B3A6B" : "#fff", color: filter === f ? "#fff" : "#4A5568", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
              {f === "all" ? `All (${requests.length})` : `${STATUS_COLORS[f]?.label} (${counts[f] || 0})`}
            </button>
          ))}
        </div>

        {/* Requests */}
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "60px 0", color: "#4A5568" }}>No requests found.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {filtered.map((r) => {
              const st = STATUS_COLORS[r.status] || STATUS_COLORS["new"];
              return (
                <div key={r.id} style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 14, padding: "22px 24px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 14 }}>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                        <span style={{ fontSize: 12, color: "#4A5568", fontWeight: 600 }}>#{r.id}</span>
                        <span style={{ background: st.bg, color: st.color, fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 8 }}>{st.label}</span>
                        <span style={{ fontSize: 11, color: "#4A5568" }}>{new Date(r.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                      </div>
                      <div style={{ fontWeight: 700, fontSize: 16, color: "#1B3A6B" }}>{r.name}</div>
                    </div>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      <a href={`https://wa.me/91${r.phone}`} target="_blank" rel="noopener noreferrer"
                        style={{ background: "#25D366", color: "#fff", padding: "7px 14px", borderRadius: 8, fontSize: 13, fontWeight: 700, textDecoration: "none" }}>
                        💬 {r.phone}
                      </a>
                      <select value={r.status} onChange={(e) => updateStatus(r.id, e.target.value)} disabled={updating === r.id}
                        style={{ padding: "7px 12px", borderRadius: 8, border: "1.5px solid #E2E8F0", fontSize: 13, fontFamily: "'Inter', sans-serif", cursor: "pointer", background: "#fff", fontWeight: 600 }}>
                        <option value="new">🆕 New</option>
                        <option value="in_progress">⏳ In Progress</option>
                        <option value="completed">✅ Completed</option>
                        <option value="cancelled">❌ Cancelled</option>
                      </select>
                    </div>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "8px 24px", fontSize: 13 }}>
                    <div><span style={{ color: "#4A5568" }}>Plan: </span><strong style={{ color: "#C9A84C" }}>{r.service}</strong></div>
                    <div><span style={{ color: "#4A5568" }}>Transaction: </span><strong>{r.transaction}</strong></div>
                    {r.email && <div><span style={{ color: "#4A5568" }}>Email: </span><a href={`mailto:${r.email}`} style={{ color: "#1B3A6B" }}>{r.email}</a></div>}
                    <div style={{ gridColumn: "1/-1" }}><span style={{ color: "#4A5568" }}>Property: </span>{r.address}</div>
                    {r.concern && <div style={{ gridColumn: "1/-1" }}><span style={{ color: "#4A5568" }}>Concern: </span><em>{r.concern}</em></div>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
