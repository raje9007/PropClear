import { useState, useRef } from "react";

const WHATSAPP = "919354599207";
const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const services = [
  { value: "Property Consultation — ₹499", label: "💬 Property Consultation — ₹499" },
  { value: "Document Check — ₹999", label: "📄 Document Check — ₹999" },
  { value: "Complete Property Report — ₹1,999", label: "🔍 Complete Property Report — ₹1,999" },
  { value: "PM-UDAY End-to-End — ₹15,000", label: "🏠 PM-UDAY End-to-End — ₹15,000" },
];

const transactionTypes = [
  "Buying Property",
  "Selling Property",
  "Home Loan",
  "Freehold Conversion",
  "Mutation / Name Transfer",
  "PM-UDAY Regularization",
  "Other",
];

function inputStyle(hasError: boolean): React.CSSProperties {
  return {
    width: "100%",
    padding: "11px 14px",
    border: `1.5px solid ${hasError ? "#E53E3E" : "#E2E8F0"}`,
    borderRadius: 8,
    fontSize: 14,
    fontFamily: "'Inter', sans-serif",
    color: "#1A1A2E",
    background: "#fff",
    outline: "none",
    boxSizing: "border-box",
  };
}

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "", service: "", transaction: "", concern: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  function validate() {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Please enter your name";
    if (!form.phone.trim() || form.phone.length < 10) e.phone = "Please enter a valid 10-digit WhatsApp number";
    if (!form.address.trim()) e.address = "Please enter the property address";
    if (!form.service) e.service = "Please select a plan";
    if (!form.transaction) e.transaction = "Please select a transaction type";
    return e;
  }

  async function submitForm(e: React.FormEvent) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    try {
      await fetch(`${BASE}/api/requests`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          phone: form.phone,
          email: form.email || undefined,
          address: form.address,
          service: form.service,
          transaction: form.transaction,
          concern: form.concern || undefined,
        }),
      });
    } catch {
      // silent — still proceed to WhatsApp
    }

    const msg = `🔍 *PropClear Verification Request*\n\n👤 Name: ${form.name}\n📱 Phone: ${form.phone}\n📍 Property: ${form.address}\n📋 Plan: ${form.service}\n🏠 Transaction: ${form.transaction}${form.concern ? `\n💬 Concern: ${form.concern}` : ""}\n\n_Sent via PropClear Website_`;
    setSubmitted(true);
    setTimeout(() => { window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, "_blank"); }, 1500);
  }

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", color: "#1A1A2E" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #122952, #1B3A6B)", padding: "56px 24px 48px", textAlign: "center" }}>
        <div style={{ color: "#C9A84C", fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>Get Started</div>
        <h1 style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: "clamp(26px, 4vw, 40px)", marginBottom: 14 }}>Submit Your Documents</h1>
        <p style={{ color: "rgba(255,255,255,0.75)", fontSize: 16, maxWidth: 480, margin: "0 auto" }}>Fill the form and your report will be ready within 48 hours. Everything on WhatsApp.</p>
      </div>

      <section style={{ padding: "60px 24px", background: "#F5F7FA" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 40, maxWidth: 1000, margin: "0 auto", alignItems: "start" }}>

          {/* Left: Contact Info */}
          <div>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 24, color: "#1B3A6B", marginBottom: 18 }}>Contact PropClear</h2>

            {[
              { icon: "📱", title: "WhatsApp", info: "+91 93545 99207", link: `https://wa.me/${WHATSAPP}`, sub: "Usually replies within 2 hours" },
              { icon: "📧", title: "Email", info: "propclear.in@gmail.com", link: "mailto:propclear.in@gmail.com", sub: "For document submissions" },
              { icon: "📍", title: "Coverage Area", info: "Delhi NCR", link: undefined, sub: "Delhi, Noida, Gurgaon, Faridabad, Ghaziabad" },
              { icon: "⏰", title: "Working Hours", info: "Mon–Sat, 9am–7pm", link: undefined, sub: "WhatsApp available till 9pm" },
            ].map((c) => (
              <div key={c.title} style={{ display: "flex", gap: 16, marginBottom: 24, alignItems: "flex-start" }}>
                <div style={{ width: 44, height: 44, background: "#1B3A6B", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, minWidth: 44 }}>
                  {c.icon}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: "#1B3A6B", marginBottom: 2 }}>{c.title}</div>
                  {c.link ? (
                    <a href={c.link} style={{ color: "#C9A84C", fontSize: 14, fontWeight: 600, textDecoration: "none" }}>{c.info}</a>
                  ) : (
                    <div style={{ color: "#C9A84C", fontSize: 14, fontWeight: 600 }}>{c.info}</div>
                  )}
                  <div style={{ fontSize: 12, color: "#4A5568", marginTop: 2 }}>{c.sub}</div>
                </div>
              </div>
            ))}

            <div style={{ background: "#1B3A6B", borderRadius: 12, padding: "20px 22px", marginTop: 8 }}>
              <div style={{ color: "#C9A84C", fontWeight: 700, fontSize: 14, marginBottom: 8 }}>⚡ Quick Response Guarantee</div>
              <p style={{ fontSize: 13, color: "rgba(255,255,255,0.8)", lineHeight: 1.7 }}>
                Form submit karne ke 2 ghante ke andar hum aapko WhatsApp pe contact karenge — payment details aur confirmation ke saath.
              </p>
            </div>
          </div>

          {/* Right: Form */}
          <div style={{ background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 16, padding: "36px 30px", boxShadow: "0 4px 24px rgba(27,58,107,0.08)" }}>
            {!submitted ? (
              <form onSubmit={submitForm} noValidate>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#1B3A6B", marginBottom: 6 }}>Verification Request</h3>
                <p style={{ fontSize: 13, color: "#4A5568", marginBottom: 26 }}>Fields marked <span style={{ color: "#E53E3E" }}>*</span> are required. Documents are 100% secure.</p>

                {/* Name + Phone */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 14, marginBottom: 16 }}>
                  <div>
                    <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Name <span style={{ color: "#E53E3E" }}>*</span></label>
                    <input type="text" placeholder="Full name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} style={inputStyle(!!errors.name)} />
                    {errors.name && <p style={{ fontSize: 11, color: "#E53E3E", marginTop: 3 }}>{errors.name}</p>}
                  </div>
                  <div>
                    <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>WhatsApp <span style={{ color: "#E53E3E" }}>*</span></label>
                    <input type="tel" placeholder="10-digit number" maxLength={10} value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} style={inputStyle(!!errors.phone)} />
                    {errors.phone && <p style={{ fontSize: 11, color: "#E53E3E", marginTop: 3 }}>{errors.phone}</p>}
                  </div>
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Email <span style={{ fontSize: 12, color: "#4A5568", fontWeight: 400 }}>(optional)</span></label>
                  <input type="email" placeholder="your@email.com" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} style={inputStyle(false)} />
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Property Address <span style={{ color: "#E53E3E" }}>*</span></label>
                  <textarea placeholder="Full address — colony, sector, district, Delhi NCR" value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} style={{ ...inputStyle(!!errors.address), resize: "vertical", minHeight: 72 }} />
                  {errors.address && <p style={{ fontSize: 11, color: "#E53E3E", marginTop: 3 }}>{errors.address}</p>}
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Select Plan <span style={{ color: "#E53E3E" }}>*</span></label>
                  <select value={form.service} onChange={(e) => setForm((f) => ({ ...f, service: e.target.value }))} style={inputStyle(!!errors.service)}>
                    <option value="">— Choose a plan —</option>
                    {services.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                  {errors.service && <p style={{ fontSize: 11, color: "#E53E3E", marginTop: 3 }}>{errors.service}</p>}
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Transaction Type <span style={{ color: "#E53E3E" }}>*</span></label>
                  <select value={form.transaction} onChange={(e) => setForm((f) => ({ ...f, transaction: e.target.value }))} style={inputStyle(!!errors.transaction)}>
                    <option value="">— Why are you verifying? —</option>
                    {transactionTypes.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                  {errors.transaction && <p style={{ fontSize: 11, color: "#E53E3E", marginTop: 3 }}>{errors.transaction}</p>}
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Upload Documents</label>
                  <div onClick={() => fileInputRef.current?.click()}
                    style={{ border: "2px dashed #E2E8F0", borderRadius: 8, padding: 20, textAlign: "center", cursor: "pointer" }}
                    onMouseEnter={(e) => (e.currentTarget.style.borderColor = "#1B3A6B")}
                    onMouseLeave={(e) => (e.currentTarget.style.borderColor = "#E2E8F0")}
                  >
                    <input ref={fileInputRef} type="file" multiple accept=".pdf,.jpg,.jpeg,.png" style={{ display: "none" }} onChange={(e) => setFiles(Array.from(e.target.files || []))} />
                    <div style={{ fontSize: 24, marginBottom: 4 }}>📎</div>
                    <p style={{ fontSize: 13, color: "#4A5568" }}><strong style={{ color: "#1B3A6B" }}>Click to upload</strong><br />PDF, JPG, PNG — max 10MB</p>
                  </div>
                  {files.map((f) => (
                    <div key={f.name} style={{ fontSize: 12, color: "#2D7D46", marginTop: 4 }}>✅ {f.name} ({(f.size / 1024).toFixed(0)} KB)</div>
                  ))}
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#1B3A6B", marginBottom: 6 }}>Specific Concerns <span style={{ fontSize: 12, color: "#4A5568", fontWeight: 400 }}>(optional)</span></label>
                  <textarea placeholder="Any specific issue you want checked?" value={form.concern} onChange={(e) => setForm((f) => ({ ...f, concern: e.target.value }))} style={{ ...inputStyle(false), resize: "vertical", minHeight: 68 }} />
                </div>

                <div style={{ background: "#F5F7FA", borderLeft: "3px solid #C9A84C", padding: "11px 14px", borderRadius: 4, fontSize: 12, color: "#4A5568", lineHeight: 1.6, marginBottom: 20 }}>
                  ⚠️ <strong>Disclaimer:</strong> PropClear reports are a due diligence tool based on publicly available government records — not a legal opinion.
                </div>

                <button type="submit" style={{ width: "100%", background: "#1B3A6B", color: "#fff", border: "none", padding: 15, borderRadius: 8, fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#122952")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "#1B3A6B")}
                >
                  Submit Verification Request →
                </button>
              </form>
            ) : (
              <div style={{ textAlign: "center", padding: "40px 16px" }}>
                <div style={{ width: 72, height: 72, background: "#E6F4EC", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: 32 }}>✅</div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 24, color: "#1B3A6B", marginBottom: 10 }}>Request Submitted!</h3>
                <p style={{ color: "#4A5568", fontSize: 15, lineHeight: 1.75, marginBottom: 24 }}>
                  Thank you! We have received your verification request.<br /><br />
                  <strong>Next step:</strong> We will contact you on WhatsApp within <strong>2 hours</strong> with payment details.<br /><br />
                  Your report will be ready within <strong>48 hours</strong>.
                </p>
                <a href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noopener noreferrer" style={{ background: "#25D366", color: "#fff", padding: "13px 28px", borderRadius: 8, fontWeight: 700, fontSize: 15, textDecoration: "none", display: "inline-block" }}>
                  💬 Chat on WhatsApp
                </a>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
