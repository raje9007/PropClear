import { useState } from "react";
import { Link, useLocation } from "wouter";

const navLinks = [
  { label: "Home", href: "/" },
  { label: "Services", href: "/services" },
  { label: "FAQ", href: "/faq" },
  { label: "Blog", href: "/blog" },
  { label: "Contact Us", href: "/contact" },
  { label: "Submit Documents", href: "/submit", cta: true },
];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();

  return (
    <>
      <nav style={{
        background: "#1B3A6B",
        padding: "0 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        position: "sticky",
        top: 0,
        zIndex: 100,
        boxShadow: "0 2px 12px rgba(0,0,0,0.2)",
        minHeight: 64,
      }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none" }}>
          <img
            src="/propclear-logo.jpg"
            alt="PropClear Logo"
            style={{ width: 46, height: 46, borderRadius: "50%", objectFit: "cover", border: "2px solid #C9A84C" }}
          />
          <span style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: 21, fontWeight: 700 }}>
            Prop<span style={{ color: "#C9A84C" }}>Clear</span>
          </span>
        </Link>

        {/* Desktop */}
        <div style={{ display: "flex", alignItems: "center", gap: 4 }} className="hidden md:flex">
          {navLinks.map((l) => {
            const active = location === l.href;
            if (l.cta) {
              return (
                <Link key={l.label} href={l.href} style={{
                  background: "#C9A84C",
                  color: "#122952",
                  textDecoration: "none",
                  fontSize: 13,
                  fontWeight: 700,
                  padding: "8px 18px",
                  borderRadius: 6,
                  marginLeft: 8,
                }}>
                  {l.label}
                </Link>
              );
            }
            return (
              <Link key={l.label} href={l.href} style={{
                color: active ? "#C9A84C" : "rgba(255,255,255,0.78)",
                textDecoration: "none",
                fontSize: 13,
                fontWeight: 500,
                padding: "8px 14px",
                borderRadius: 6,
                background: active ? "rgba(201,168,76,0.1)" : "transparent",
                borderBottom: active ? "2px solid #C9A84C" : "2px solid transparent",
              }}>
                {l.label}
              </Link>
            );
          })}
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden"
          onClick={() => setMenuOpen(!menuOpen)}
          style={{ background: "none", border: "none", cursor: "pointer", padding: 8 }}
          aria-label="Menu"
        >
          {menuOpen ? (
            <span style={{ color: "#fff", fontSize: 22 }}>✕</span>
          ) : (
            <div>
              <div style={{ width: 22, height: 2, background: "#fff", marginBottom: 5 }} />
              <div style={{ width: 22, height: 2, background: "#fff", marginBottom: 5 }} />
              <div style={{ width: 22, height: 2, background: "#fff" }} />
            </div>
          )}
        </button>
      </nav>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{ background: "#122952", padding: "12px 24px 20px", position: "sticky", top: 64, zIndex: 99 }}>
          {navLinks.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setMenuOpen(false)}
              style={{
                display: "block",
                color: location === l.href ? "#C9A84C" : "rgba(255,255,255,0.85)",
                textDecoration: "none",
                fontSize: 15,
                fontWeight: 500,
                padding: "12px 0",
                borderBottom: "1px solid rgba(255,255,255,0.1)",
              }}
            >
              {l.label === "Contact" ? "📩 Submit Documents" : l.label}
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
