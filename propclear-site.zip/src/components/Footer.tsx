import { Link } from "wouter";

export const WHATSAPP = "919354599207";
export const EMAIL = "propclear.in@gmail.com";

export default function Footer() {
  return (
    <footer style={{ background: "#122952", color: "rgba(255,255,255,0.7)", padding: "48px 24px 24px", textAlign: "center" }}>
      <div style={{ maxWidth: 700, margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 12, marginBottom: 14 }}>
          <img src="/propclear-logo.jpg" alt="PropClear" style={{ width: 52, height: 52, borderRadius: "50%", objectFit: "cover", border: "2px solid #C9A84C" }} />
          <span style={{ fontFamily: "'Playfair Display', serif", color: "#fff", fontSize: 24 }}>
            Prop<span style={{ color: "#C9A84C" }}>Clear</span>
          </span>
        </div>
        <p style={{ fontSize: 13, lineHeight: 1.8, marginBottom: 16 }}>
          Delhi NCR's trusted property document verification service.<br />
          DDA · MCD · DORIS · CERSAI · eCourts — all portals covered.
        </p>

        <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "8px 24px", marginBottom: 20, fontSize: 13 }}>
          {["/", "/services", "/faq", "/blog", "/contact"].map((href, i) => {
            const labels = ["Home", "Services", "FAQ", "Blog", "Contact"];
            return (
              <Link key={href} href={href} style={{ color: "#C9A84C", textDecoration: "none" }}>
                {labels[i]}
              </Link>
            );
          })}
        </div>

        <p style={{ fontSize: 13, marginBottom: 20 }}>
          📱 WhatsApp:{" "}
          <a href={`https://wa.me/${WHATSAPP}`} style={{ color: "#C9A84C" }}>+91 93545 99207</a>
          &nbsp;|&nbsp;
          📧 <a href={`mailto:${EMAIL}`} style={{ color: "#C9A84C" }}>{EMAIL}</a>
        </p>

        <div style={{
          fontSize: 11,
          color: "rgba(255,255,255,0.35)",
          borderTop: "1px solid rgba(255,255,255,0.1)",
          paddingTop: 16,
          lineHeight: 1.7,
        }}>
          PropClear reports are a due diligence tool based on publicly available government records — not a legal opinion.
          For complex cases, a legal review adds an extra layer of protection.<br />
          © {new Date().getFullYear()} PropClear Delhi NCR. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
